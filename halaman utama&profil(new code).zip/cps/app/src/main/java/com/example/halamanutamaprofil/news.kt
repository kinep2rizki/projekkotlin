package com.example.halamanutamaprofil

data class news(var titleimage : Int, var heading : String)
