package com.example.halamanutamaprofil

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView

class adapter(private val newslist : ArrayList<news>):
    RecyclerView.Adapter<adapter.myviewholder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): myviewholder {
        val itemview = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return myviewholder(itemview)
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")

        return newslist.size
    }

    override fun onBindViewHolder(holder: myviewholder, position: Int) {
        val currentitem = newslist[position]
        holder.titleimage.setImageResource(currentitem.titleimage)
        holder.tvheading.text = currentitem.heading
    }
}

class myviewholder(itemview : View) : RecyclerView.ViewHolder(itemview){

    val titleimage : ShapeableImageView = itemview.findViewById(R.id.title_image)
    val tvheading : TextView = itemview.findViewById(R.id.tvHeading)
}