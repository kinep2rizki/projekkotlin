package com.example.halamanutamaprofil

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class halprofil : AppCompatActivity() {

    lateinit var btn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_halprofil)
        btn = requireViewById(R.id.bt_button)
        btn.setOnClickListener {
                val i = Intent(this, MainActivity::class.java)
                startActivity(i)
                finish()
    }
}
}